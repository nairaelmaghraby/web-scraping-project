import requests
from bs4 import BeautifulSoup
import csv
from itertools import zip_longest

doctor_name = []
speciality = []
location = []
fees = []
page_num = 0

while True:
        result = requests.get(f"https://www.vezeeta.com/en/doctor/dentistry/egypt?page={page_num}")
        src = result.content
        data = BeautifulSoup(src, "lxml")

        if (page_num == 94):
            break
        doctor_name = data.find_all("span", {"class":"DoctorCardSubComponentsstyle__Text-sc-1vq3h7c-14 DoctorCardSubComponentsstyle__DoctorNameText-sc-1vq3h7c-15 dZnRSf Wpycp"})
        speciality = data.find_all("a", {"class":"DoctorCardSubComponentsstyle__Link-sc-1vq3h7c-18 ivqRik"})
        location = data.find_all("span", itemprop="address")
        fees = data.find_all("span", itemprop="priceRange")
        #print(doctor_name)
        for i in range(len(doctor_name)):
            doctor_name.append(doctor_name[i].text)
            speciality.append(speciality[i].text)
            location.append(location[i].text)
            fees.append(fees[i].text)
            print(doctor_name)
        page_num += 1
        print("page switched")
file_list = [doctor_name, speciality, location, fees]
exported = zip_longest(*file_list)
with open("D:\csv file\DataTest.csv", "w") as MyFile:
    wr = csv.writer(MyFile)
    wr.writerow(["Doctor Name", "Speciality", "Location", "Fees"])
    wr.writerow(exported)